# 复现说明（run `20260912-212914-2b9c081`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `e2661b87f5ede1e1abe4db932c76af06b104248b`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| bench | completed | 374.0 | `d8dd8de945aa6faf` | `ta-01M2AX976TBW8MBR06GN1VA3RR` |
| coldstart | completed | 2686.0 | `80937018244e5471` | `ta-01M2BD6KV6K9ZXJ846XB105J5R` |
| compare | completed | 1.0 | `5948163a2fcada53` | `ta-01M2BR9DF1RZ7JG42XESQ4G8FR` |
| detect | completed | 1.0 | `f45963852b4a41e0` | `ta-01M2AX112C2161S2QBF900D9ZR` |
| figures | completed | 17.0 | `7863b6bd623beaaf` | `ta-01M2BRKRYQ2FKCCSVQC4SXQE9R` |
| fmt | completed | 1.0 | `8fb31c07c4242e8f` | `ta-01M2BRZC1BWYH8VN0K3G7VASZR` |
| ingest | completed | 0.0 | `1c6f1c5a038c5641` | `ta-01M2AX112C2161S2QBF900D9ZR` |
| lint | completed | 20.0 | `a9c8365db560dfe6` | `ta-01M2B9GZCS60JN5PGCRZSA0FER` |
| pack | completed | 109.0 | `796e88a956d04b78` | `ta-01M2BRFG8AW9JESXFM80F3QN9R` |
| package | running | 0.0 | `` | `ta-01M2BS9TRQKPPWS7QNTPD8W81R` |
| paper | completed | 50.0 | `d8cf59ebb97391d0` | `ta-01M2BS7B191CBH6JM8A0847VJR` |
| qa | completed | 0.0 | `16ba3671ae92e4df` | `ta-01M2BS7B191CBH6JM8A0847VJR` |
| resolve | completed | 2550.0 | `d4899aa501acdb52` | `ta-01M2B9JZMQ5AM2P08FV91PVE3R` |
| resolve_interval | completed | 7807.0 | `a7aa2df9db2cd81f` | `ta-01M2BGS9RP211B4HA3JFCKEBJR` |
| results | completed | 2.0 | `6f4a2dc4aeddc8be` | `ta-01M2BR9DF1RZ7JG42XESQ4G8FR` |
| sensitivity | completed | 1003.0 | `6f95b8983a559c0c` | `ta-01M2BD656B00XN6WZ6FDBQ659R` |
| tables | completed | 2.0 | `4ad5e01d9277db8c` | `ta-01M2BRZY8NYYAC9QEJY87C9DRR` |
| test | completed | 15.0 | `6bc4ffc701d1f8a8` | `ta-01M2B9GZCS60JN5PGCRZSA0FER` |
| validate | completed | 0.0 | `4dad00dd81738849` | `ta-01M2AX112C2161S2QBF900D9ZR` |

## 复现命令

### A. 云端（本文使用的方式，需要 Modal 账号）

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run bench --size medium
python3 tools/cli.py run coldstart --size medium
python3 tools/cli.py run compare --size medium
python3 tools/cli.py run detect --size medium
python3 tools/cli.py run figures --size medium
python3 tools/cli.py run lint --size medium
python3 tools/cli.py run pack --size medium
python3 tools/cli.py run package --size medium
python3 tools/cli.py run paper --size medium
python3 tools/cli.py run qa --size medium
python3 tools/cli.py run resolve --size medium
python3 tools/cli.py run resolve_interval --size medium
python3 tools/cli.py run results --size medium
python3 tools/cli.py run sensitivity --size medium
python3 tools/cli.py run tables --size medium
python3 tools/cli.py run test --size medium
python3 tools/cli.py release --version <tag>
```

各阶段的确切参数（线程数、逐级时限）见每个阶段目录下 `manifest.json` 的 `params` 字段，
以及 `docs/RUNBOOK.md` 第 7 节。

### B. 本地（不需要任何云端账号）

```bash
pip install pandas numpy openpyxl pyarrow networkx matplotlib ortools highspy
python3 tools/run_local.py --quick        # 数分钟，得到 result1-4.xlsx、图与表
python3 tools/run_local.py                # 使用默认（较大）预算
```

本地驱动脚本调用的是同一批阶段函数，只是把云端卷换成本地目录；
附件需按原样放在 `附件/` 下。论文排版阶段（paper/qa/package/release）需要 TeX Live 与中文字体，
不在本地默认序列中。

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
