# 复现说明（run `20260912-102234-ea48b61`）

本目录内所有结果均由 Modal 云端按下列阶段生成；本地只提交任务、下载和核对 SHA-256。

- 代码版本：git `2e3752aec2eae040e5d201c037a081aaec601395`（分支 `main`）
- 运行环境：Python 3.11.12，Linux-4.19.0-gvisor-x86_64-with-glibc2.36
- 依赖版本：cvxpy==1.6.5, highspy==1.10.0, hypothesis==6.131.9, matplotlib==3.10.3, mypy==1.15.0, networkx==3.4.2, numba==0.61.2, numpy==2.2.6, openpyxl==3.1.5, ortools==9.12.4544, pandas==2.2.3, pyarrow==20.0.0, pymupdf==1.26.7, pytest==8.3.5, ruff==0.11.10, scikit-learn==1.6.1, scipy==1.15.3, statsmodels==0.14.4

## 阶段

| 阶段 | 状态 | 用时 (s) | 输出摘要 | Modal 任务 |
|---|---|---:|---|---|
| bench | completed | 375.0 | `45603a6ec806c54d` | `ta-01M2A6HYJV8K2DDTHPN88FE7SR` |
| compare | completed | 0.0 | `16ef61ffedc36d23` | `ta-01M2A7QXGMBZ6DGKMCS8X93Y3R` |
| detect | completed | 1.0 | `b64918146437b8f5` | `ta-01M29PS5GRPVK7TRBYEWTPN0KR` |
| figures | completed | 14.0 | `4d7ea02b97ce7f9f` | `ta-01M2A7SVJ8TXTWGGA12HXYCJNR` |
| fmt | completed | 0.0 | `2b76b8e107587f81` | `ta-01M2AA7BENHH8Q08RWZH1449VR` |
| ingest | completed | 0.0 | `1c6f1c5a038c5641` | `ta-01M29PS5GRPVK7TRBYEWTPN0KR` |
| lint | completed | 14.0 | `cd5e1ca31d0d8559` | `ta-01M2AA7TW4R1XWN2KS6QYJT4YR` |
| pack | completed | 129.0 | `a2d2e31303774072` | `ta-01M2A6HH1XN4CW4JR000XAE4FR` |
| package | running | 0.0 | `` | `ta-01M2ACZEEFTV9YPGM2NBS99HAR` |
| paper | completed | 62.0 | `488ef17d5fc6980e` | `ta-01M2ACW55G51VZ82ZQZ74FWTQR` |
| qa | completed | 1.0 | `5fb541f84015918b` | `ta-01M2ACW55G51VZ82ZQZ74FWTQR` |
| release | completed | 0.0 | `56d764d705260330` | `ta-01M2ACFEJY9Q3BHT8PKCKE570R` |
| resolve | completed | 2286.0 | `1ed01f40c94dbf21` | `ta-01M2A2S8X1R9WHT7DXT2QMFMHR` |
| resolve_interval | completed | 2546.0 | `ab59b59918636d48` | `ta-01M2A52QXZKBM8702SR14304VR` |
| results | completed | 1.0 | `e2f11074506556a2` | `ta-01M2A7QXGMBZ6DGKMCS8X93Y3R` |
| sensitivity | completed | 1003.0 | `1ee2b3594487abb7` | `ta-01M2A6JFB40WJ35Q0ZE79CQN0R` |
| tables | completed | 4.0 | `5c4704b3ec4a2213` | `ta-01M2AA7TW4R1XWN2KS6QYJT4YR` |
| test | completed | 11.0 | `d964bbe98b59f8a3` | `ta-01M2AA7TW4R1XWN2KS6QYJT4YR` |
| validate | completed | 0.0 | `4dad00dd81738849` | `ta-01M29PS5GRPVK7TRBYEWTPN0KR` |

## 复现命令

```bash
python3 tools/cli.py provision
python3 tools/cli.py run ingest,validate --new-run
python3 tools/cli.py run <科学阶段...> --size medium
python3 tools/cli.py run lint,test,paper,qa,package,release
python3 tools/cli.py release --version <tag>
```

每个阶段目录下的 `manifest.json` 记录输入、输出散列、参数与环境；`events.jsonl` 为结构化日志。
